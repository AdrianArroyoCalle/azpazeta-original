#include "tren.h"
#include "save.h"
#include "inicio.hpp"
#ifndef VARGLOBAL_H_
#define VARGLOBAL_H_
/*int x, y;
int level=0;
int money=2000;
int city=0;
char name;
wxString newname;
int adrx;
int adry;
int mision=0;
int aux;*/
#endif
