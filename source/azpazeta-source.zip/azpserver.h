#ifndef AZPSERVER_H_
#define AZPSERVER_H_


class AZPServer{
public:
	void IniciarConexion();
	void PasarDatos();
	void RecibirDatos();
	void CerrarConexion();

};








#endif
